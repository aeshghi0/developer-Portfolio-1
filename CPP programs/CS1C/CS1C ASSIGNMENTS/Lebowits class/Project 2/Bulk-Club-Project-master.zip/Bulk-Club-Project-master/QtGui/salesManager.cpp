#include "salesManager.h"

salesManager::salesManager()
{

}
