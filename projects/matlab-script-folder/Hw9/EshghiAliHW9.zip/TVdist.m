function TV = TVdist(a,b)
    TV = 1/2 * norm(a-b,1);
end